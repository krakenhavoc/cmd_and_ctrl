package effects

import (
	"github.com/google/uuid"

	"github.com/krakenhavoc/cmd_and_ctrl/server/internal/game"
)

// targets.go — S20 sub-PR 1: the predicate library catalog cards
// compose their `Spec.Targets` from, plus constructors for the
// common shapes. A card file reads like its oracle text:
//
//	Targets: TargetCreature(NonBlack()),          // Doom Blade
//	Targets: TargetAny(),                         // Lightning Bolt
//	Targets: TargetSpell(Noncreature()),          // Negate
//	Targets: TargetCardInGraveyard(YourOwn()),    // Regrowth
//
// Predicates receive the live game (read-only — they run under
// g.mu), the caster, and the candidate. Compose with And / Or /
// Not. Keep them pure: no allocation-heavy scans per candidate; the
// legal-target walk calls them once per card on the battlefield /
// stack / graveyards on every snapshot.

// CardPredicate decides whether a candidate card is a legal target
// for the caster.
type CardPredicate func(g *game.Game, caster uuid.UUID, c game.Card) bool

// PlayerPredicate decides whether a candidate player is a legal
// target for the caster.
type PlayerPredicate func(g *game.Game, caster uuid.UUID, p *game.Player) bool

// --- composers -------------------------------------------------

// And passes when every predicate passes (empty list passes).
func And(preds ...CardPredicate) CardPredicate {
	return func(g *game.Game, caster uuid.UUID, c game.Card) bool {
		for _, p := range preds {
			if !p(g, caster, c) {
				return false
			}
		}
		return true
	}
}

// Or passes when any predicate passes (empty list fails).
func Or(preds ...CardPredicate) CardPredicate {
	return func(g *game.Game, caster uuid.UUID, c game.Card) bool {
		for _, p := range preds {
			if p(g, caster, c) {
				return true
			}
		}
		return false
	}
}

// Not inverts a predicate.
func Not(pred CardPredicate) CardPredicate {
	return func(g *game.Game, caster uuid.UUID, c game.Card) bool {
		return !pred(g, caster, c)
	}
}

// --- type predicates (post-layer, so type-changers compose) ----

func Creature() CardPredicate {
	return func(_ *game.Game, _ uuid.UUID, c game.Card) bool { return c.IsCreature() }
}

func Artifact() CardPredicate {
	return func(_ *game.Game, _ uuid.UUID, c game.Card) bool { return c.IsArtifact() }
}

func Enchantment() CardPredicate {
	return func(_ *game.Game, _ uuid.UUID, c game.Card) bool { return c.IsEnchantment() }
}

func Land() CardPredicate {
	return func(_ *game.Game, _ uuid.UUID, c game.Card) bool { return c.IsLand() }
}

func Instant() CardPredicate {
	return func(_ *game.Game, _ uuid.UUID, c game.Card) bool { return c.IsInstant() }
}

func Sorcery() CardPredicate {
	return func(_ *game.Game, _ uuid.UUID, c game.Card) bool { return c.IsSorcery() }
}

func Planeswalker() CardPredicate {
	return func(_ *game.Game, _ uuid.UUID, c game.Card) bool { return c.IsPlaneswalker() }
}

// Permanent passes for any permanent-type card (on the battlefield
// every card is one; on the stack it distinguishes permanent spells
// from instants / sorceries).
func Permanent() CardPredicate {
	return func(_ *game.Game, _ uuid.UUID, c game.Card) bool { return c.IsPermanent() }
}

// Nonland passes for anything that isn't a land.
func Nonland() CardPredicate { return Not(Land()) }

// Noncreature passes for anything that isn't a creature (Negate's
// "noncreature spell").
func Noncreature() CardPredicate { return Not(Creature()) }

// --- colour predicates -------------------------------------------

// OfColor passes when the card is the given colour letter.
func OfColor(color string) CardPredicate {
	return func(_ *game.Game, _ uuid.UUID, c game.Card) bool { return c.HasColor(color) }
}

// NonBlack — Doom Blade. Likewise NonBlue etc. via Not(OfColor("U")).
func NonBlack() CardPredicate { return Not(OfColor("B")) }

// Colorless passes for cards with no colour.
func Colorless() CardPredicate {
	return func(_ *game.Game, _ uuid.UUID, c game.Card) bool { return c.IsColorless() }
}

// --- stat predicates ---------------------------------------------

// PowerLE passes when the creature's current power is ≤ n.
func PowerLE(n int) CardPredicate {
	return func(_ *game.Game, _ uuid.UUID, c game.Card) bool { return c.CurrentPower() <= n }
}

// PowerGE passes when the creature's current power is ≥ n.
func PowerGE(n int) CardPredicate {
	return func(_ *game.Game, _ uuid.UUID, c game.Card) bool { return c.CurrentPower() >= n }
}

// ManaValueLE passes when the card's mana value is ≤ n (Swan Song
// doesn't need it, but Counterspell variants and Abrupt Decay do).
func ManaValueLE(n int) CardPredicate {
	return func(_ *game.Game, _ uuid.UUID, c game.Card) bool {
		cost, err := game.ParseCost(c.ManaCost)
		if err != nil {
			return false
		}
		return cost.Generic+len(cost.Required) <= n
	}
}

// --- controller / owner predicates ------------------------------

// YouControl passes for cards the caster controls.
func YouControl() CardPredicate {
	return func(_ *game.Game, caster uuid.UUID, c game.Card) bool { return c.Controller == caster }
}

// OpponentControls passes for cards controlled by someone other
// than the caster.
func OpponentControls() CardPredicate {
	return func(_ *game.Game, caster uuid.UUID, c game.Card) bool { return c.Controller != caster }
}

// YouOwn passes for cards the caster owns (graveyard targets:
// "return target card from your graveyard").
func YouOwn() CardPredicate {
	return func(_ *game.Game, caster uuid.UUID, c game.Card) bool { return c.Owner == caster }
}

// NotSelf excludes the spell / source itself — for "another target
// creature" clauses and for stack targets that shouldn't be able to
// counter themselves.
func NotSelf(selfID uuid.UUID) CardPredicate {
	return func(_ *game.Game, _ uuid.UUID, c game.Card) bool { return c.InstanceID != selfID }
}

// Opponent passes for players other than the caster.
func Opponent() PlayerPredicate {
	return func(_ *game.Game, caster uuid.UUID, p *game.Player) bool { return p.ID != caster }
}

// --- spec constructors ------------------------------------------

// TargetAny — "any target" (CR 115.4): a player, creature,
// planeswalker or battle. Lightning Bolt, Shock, Lightning Helix.
func TargetAny() *game.TargetSpec {
	return &game.TargetSpec{
		Mode:    "any",
		Label:   "any target",
		Players: true,
		Zones:   []game.ZoneKind{game.ZoneBattlefield},
		CardOK: func(g *game.Game, caster uuid.UUID, c game.Card, _ game.ZoneKind) bool {
			return c.IsCreature() || c.IsPlaneswalker() || c.IsBattle()
		},
		Min: 1, Max: 1,
	}
}

// TargetPlayer — "target player" / "target opponent" (pass
// Opponent()).
func TargetPlayer(label string, preds ...PlayerPredicate) *game.TargetSpec {
	return &game.TargetSpec{
		Mode:    "player",
		Label:   label,
		Players: true,
		PlayerOK: func(g *game.Game, caster uuid.UUID, p *game.Player) bool {
			for _, pr := range preds {
				if !pr(g, caster, p) {
					return false
				}
			}
			return true
		},
		Min: 1, Max: 1,
	}
}

// TargetCreature — "target creature" narrowed by predicates
// (NonBlack(), OpponentControls(), PowerLE(2), …).
func TargetCreature(label string, preds ...CardPredicate) *game.TargetSpec {
	return battlefieldSpec("creature", label, And(append([]CardPredicate{Creature()}, preds...)...))
}

// TargetPermanent — "target permanent" narrowed by predicates
// ("target artifact or enchantment" is
// TargetPermanent("…", Or(Artifact(), Enchantment()))).
func TargetPermanent(label string, preds ...CardPredicate) *game.TargetSpec {
	return battlefieldSpec("permanent", label, And(preds...))
}

func battlefieldSpec(mode, label string, pred CardPredicate) *game.TargetSpec {
	return &game.TargetSpec{
		Mode:  mode,
		Label: label,
		Zones: []game.ZoneKind{game.ZoneBattlefield},
		CardOK: func(g *game.Game, caster uuid.UUID, c game.Card, _ game.ZoneKind) bool {
			return pred(g, caster, c)
		},
		Min: 1, Max: 1,
	}
}

// TargetSpell — "target spell" on the stack, narrowed by predicates
// (Noncreature() for Negate, Creature() for Essence Scatter).
func TargetSpell(label string, preds ...CardPredicate) *game.TargetSpec {
	pred := And(preds...)
	return &game.TargetSpec{
		Mode:  "stack_spell",
		Label: label,
		Zones: []game.ZoneKind{game.ZoneStack},
		CardOK: func(g *game.Game, caster uuid.UUID, c game.Card, _ game.ZoneKind) bool {
			return pred(g, caster, c)
		},
		Min: 1, Max: 1,
	}
}

// TargetCardInGraveyard — "target card in a graveyard", narrowed by
// predicates (YouOwn() for "your graveyard", Creature() for
// "creature card").
func TargetCardInGraveyard(label string, preds ...CardPredicate) *game.TargetSpec {
	pred := And(preds...)
	return &game.TargetSpec{
		Mode:  "card_in_graveyard",
		Label: label,
		Zones: []game.ZoneKind{game.ZoneGraveyard},
		CardOK: func(g *game.Game, caster uuid.UUID, c game.Card, _ game.ZoneKind) bool {
			return pred(g, caster, c)
		},
		Min: 1, Max: 1,
	}
}
