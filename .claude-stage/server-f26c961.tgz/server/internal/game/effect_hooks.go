package game

import "github.com/google/uuid"

// effect_hooks.go holds the function-variable slots that the S14
// card-effect catalog populates from its own init() block. The
// game package can't directly import server/internal/cards/effects
// (effects needs to reach into *Game for mutations, so that
// direction is the one that builds cleanly). Dependency inversion
// via exported `var` callbacks breaks the cycle:
//
//   game  ──  EffectResolver / ETBEffectHook / IsCatalogCard  ──┐
//                                                                │ populates at init
//   effects (imports game) ───────────────────────────────────────┘
//
// main.go blank-imports effects so the init fires at server boot.
// With no import, the hooks stay nil and the resolution path falls
// back to today's manual sandbox behaviour — the catalog is opt-in
// at the server build level too.
//
// Added in S14 sub-PR 3.

// EffectResolver is invoked from resolveTopOfStackLocked after the
// target re-check and before zone routing. Implementations look up
// the spell's oracle ID (stable across printings) in the catalog
// and run the registered OnResolve callback if present. Nil means
// "no catalog wired" — the resolution path skips the call and
// relies on the manual sandbox behaviour.
//
// Implementations MUST NOT take g.mu — the resolution path already
// holds it. Use *ForEffect helpers on *Game.
var EffectResolver func(g *Game, item *StackItem, oracleID string) error

// ETBEffectHook fires after a permanent crosses into the
// battlefield from any source (land cast, spell resolution,
// MoveCardByID into battlefield). Implementations look up the
// card's oracle ID in the catalog and run the registered OnETB
// callback + stamp StartingLoyalty for planeswalkers.
var ETBEffectHook func(g *Game, cardID uuid.UUID, oracleID string) error

// CatalogStartingLoyalty returns the catalog's declared starting
// loyalty for an oracle ID, or 0 when the card has no catalog entry
// (or is not a planeswalker). It is a FALLBACK only: the printed
// value on Card.StartingLoyalty, stamped by the deck importer from
// Scryfall, always wins. The catalog answer exists for cards that
// never went through deck import — tokens, test fixtures, and the
// demo seed.
//
// Nil hook means "no catalog wired", which is the normal state in
// the game package's own tests and in a server built without the
// effects blank import. Loyalty still works in that configuration;
// that is the point of moving the stamp here (issue #274).
var CatalogStartingLoyalty func(oracleID string) int

// IsCatalogCard reports whether an oracle ID is present in the
// card-effect catalog. Used by the view layer (protocol.CardView)
// to stamp the `auto` bit so the client can render the auto badge.
// Nil is treated as "no catalog wired" → every card looks manual.
var IsCatalogCard func(oracleID string) bool

// CatalogTargetMode returns the registered card's announce-time
// target prompt shape (see effects.Spec.TargetMode) or empty
// string when no catalog entry matches. Nil hook always returns
// empty. Serialised onto CardView.TargetMode for the client's
// cast-targeting UI.
var CatalogTargetMode func(oracleID string) string

// ManaAbilityShape is the minimal mana-ability surface the game
// package consumes. Mirrors effects.ManaAbility but lives in `game`
// to avoid an import cycle (the effects package already imports
// `game`). The S15 dispatcher reads this on every
// activate_mana_ability call to look up the ability's cost shape +
// produced-mana string.
type ManaAbilityShape struct {
	TapCost bool
	// SacrificeCost sacrifices the SOURCE as part of the cost
	// (Treasure, Lotus Petal, an Eldrazi Spawn).
	SacrificeCost bool
	// SacrificeOther sacrifices one OTHER permanent the activator
	// controls, matched against this spec — Ashnod's Altar's
	// "Sacrifice a creature". The activator names it in
	// ManaAbilityParams.SacrificeIDs.
	//
	// Distinct from SacrificeCost because the two compose: a card
	// could in principle eat itself and something else. The source
	// is a legal choice when the spec admits it, exactly as on an
	// activated ability's SacrificeOther (Carrion Feeder eats
	// itself), so validation rejects naming the same permanent
	// twice rather than assuming they differ.
	//
	// Added in the S21 mana-cost pass.
	SacrificeOther *TargetSpec

	// LifeCost is a life component in the activation cost (CR
	// 118.8) — Mana Confluence's "{T}, Pay 1 life: Add one mana of
	// any color". Mirrors AbilityCost.Life, which CR 602 activated
	// abilities have carried since S21. Validated before anything
	// is paid and paid after the tap, so an attempt at too low a
	// life total fails without tapping the source.
	//
	// A life COST is not the same thing as a Rider that loses life:
	// a cost is checked and paid up front and makes the ability
	// unactivatable when it can't be met, while a rider is part of
	// the ability's effect and happens no matter what. Ancient Tomb
	// ("Add {C}{C}. This land deals 2 damage to you") is a rider and
	// can be activated at 1 life; Mana Confluence is a cost and
	// cannot be activated at 0.
	//
	// Added in the S22 mana-ability-rider pass.
	LifeCost int

	Produced string
	Label    string

	// Rider is the post-production half of a mana ability whose
	// oracle text continues past the "Add …" clause — the painland
	// cycle's "This land deals 1 damage to you", Ancient Tomb's 2.
	// It runs immediately after the produced mana lands in the
	// controller's pool, in printed order, as part of the same
	// atomic mana-ability resolution (CR 605.3a — no stack, no
	// priority window in between).
	//
	// `source` is the activating permanent's instance ID and may
	// already have left the battlefield when the ability also had a
	// sacrifice cost, so the rider gets the ID rather than a *Card
	// and must not assume the permanent is still there.
	//
	// Runs under g.mu held in write mode (ActivateManaAbility holds
	// it): use *ForEffect helpers only, never a public locking
	// mutator. A rider that changes life totals does NOT need to run
	// its own state-based-action pass — ActivateManaAbility runs one
	// on the way out whenever a rider fired.
	//
	// Nil for the overwhelming majority of mana abilities.
	//
	// Added in the S22 mana-ability-rider pass.
	Rider func(g *Game, controller, source uuid.UUID) error

	// IgnoreCommanderIdentity opts a multi-option ("pipe") produced
	// string out of the commander-identity narrowing that
	// ActivateManaAbility otherwise applies to every such slot.
	//
	// That narrowing exists for Arcane Signet and Command Tower,
	// whose printed text really does say "in your commander's color
	// identity". City of Brass and Mana Confluence say "any color"
	// flatly, and the painland / Talisman duals name two specific
	// colors — none of them should be narrowed. Setting this keeps
	// the printed option set intact.
	//
	// Added in the S22 mana-ability-rider pass.
	IgnoreCommanderIdentity bool
}

// CatalogManaAbilities returns the registered mana abilities for
// the given oracle ID (one entry per `effects.Spec.ManaAbilities`
// element), or nil when no catalog entry exists / the entry has no
// mana abilities. The cards/effects package populates this hook at
// init time alongside EffectResolver / ETBEffectHook. Nil hook ⇒
// engine falls back to the synthetic basic-land ability path.
//
// Added in S15 sub-PR 2.
var CatalogManaAbilities func(oracleID string) []ManaAbilityShape

// CatalogStaticAbilities returns the registered static abilities
// for the given oracle ID (one entry per `effects.Spec.Static`
// element), or nil when no catalog entry exists / the entry has no
// statics. The cards/effects package populates this hook at init
// time alongside the other catalog hooks. Nil hook ⇒ no card has a
// static ability ⇒ the layer engine's recompute pass leaves
// effective characteristics equal to printed.
//
// Used by Game.activeStaticAbilitiesLocked at every recompute pass
// (snapshot-driven, lazy via the layerVersion counter). Added in
// S16 sub-PR 3.
var CatalogStaticAbilities func(oracleID string) []StaticAbility

// CatalogReplacements returns the registered replacement effects
// for the given oracle ID (one entry per
// `effects.Spec.Replacements` element), or nil when no catalog
// entry exists / the entry has no replacements. The cards/effects
// package populates this hook at init time alongside the other
// catalog hooks. Nil hook ⇒ no card has a replacement effect ⇒
// gatherActiveReplacementsLocked skips the catalog leg and returns
// only built-ins + test replacements.
//
// Used by Game.gatherActiveReplacementsLocked at every apply-loop
// iteration. Unlike static abilities, replacement effects fire
// PRE-event — the engine walks the battlefield to find applicable
// effects BEFORE any rule-visible mutation runs. See
// replacements.go. Added in S17 sub-PR 2.
var CatalogReplacements func(oracleID string) []ReplacementEffect

// CatalogPrintedKeywords returns the printed keyword list for the
// given oracle ID (one entry per `effects.Spec.PrintedKeywords`
// element), or nil when no catalog entry exists / the entry has no
// printed keywords. Populated at init time by the cards/effects
// package alongside the other catalog hooks.
//
// Two consumers:
//   - On-battlefield: wire.go synthesizes a self-only Layer 6
//     StaticAbility that appends each entry to the card's own
//     Characteristic.Abilities, so HasKeyword naturally picks them
//     up via Effective().Abilities.
//   - Off-battlefield: HasKeyword (keywords.go) reads directly from
//     this hook when the card has no `effective` cache (e.g. a card
//     in hand needs flash gating before cast). The layer engine
//     only maintains Effective() for battlefield cards.
//
// Nil hook ⇒ no catalog wired ⇒ off-battlefield keyword reads
// return false for every card. Added in S18 sub-PR 2.
var CatalogPrintedKeywords func(oracleID string) []string

// CatalogTriggers returns the registered triggered abilities for the
// given oracle ID (one entry per `effects.Spec.Triggered` element),
// or nil when no catalog entry exists / the entry has no triggers.
// The cards/effects package populates this hook at init time
// alongside the other catalog hooks. Nil hook ⇒ no card has an
// auto-fire trigger ⇒ the S19 harvester returns immediately on
// every event (the layerVersionBump path keeps running normally).
//
// Used by triggerHarvester.OnEvent in triggers.go on every event
// emit. Per-event walk is linear in battlefield size; the hook is
// the inner-loop oracle lookup that happens per card. Added in S19
// sub-PR 1.
var CatalogTriggers func(oracleID string) []TriggeredAbility

// fireEffectResolverLocked invokes the registered EffectResolver
// if non-nil, emits EventEffectError on failure, and swallows the
// error so the resolution path keeps moving. Caller must hold g.mu.
func (g *Game) fireEffectResolverLocked(item *StackItem, oracleID string, cardID uuid.UUID) {
	if EffectResolver == nil || oracleID == "" {
		return
	}
	if err := EffectResolver(g, item, oracleID); err != nil {
		g.EmitEvent(Event{
			Kind:     EventEffectError,
			Source:   cardID,
			ErrorMsg: err.Error(),
		})
	}
}

// fireETBHookLocked runs the two things that must happen whenever a
// card crosses onto the battlefield: the printed starting-loyalty
// stamp (CR 306.5b) and the registered ETBEffectHook. Used by every
// code path that places a card on the battlefield — land cast,
// spell resolution, reanimation, token creation, manual admin move.
// Caller must hold g.mu.
//
// The loyalty stamp runs FIRST and runs unconditionally — before
// the oracle-ID / nil-hook guards below. Issue #274: it used to
// live inside the catalog's hook (effects.fireOnETB), so it was
// skipped for any card the catalog didn't know, and the CR 704.5i
// SBA then swept the 0-loyalty planeswalker into the graveyard on
// the next priority-grant boundary.
func (g *Game) fireETBHookLocked(cardID uuid.UUID, oracleID string) {
	g.stampStartingLoyaltyLocked(cardID, oracleID)
	if ETBEffectHook == nil || oracleID == "" {
		return
	}
	if err := ETBEffectHook(g, cardID, oracleID); err != nil {
		g.EmitEvent(Event{
			Kind:     EventEffectError,
			Source:   cardID,
			ErrorMsg: err.Error(),
		})
	}
}

// stampStartingLoyaltyLocked puts a planeswalker's starting loyalty
// counters on it as it enters the battlefield (CR 306.5b). Caller
// must hold g.mu.
//
// Source precedence:
//
//  1. Card.StartingLoyalty — printed data, stamped by the deck
//     importer from Scryfall's `loyalty` field. This is the normal
//     path for every card a player actually brought to the game.
//  2. CatalogStartingLoyalty(oracleID) — the effects catalog's
//     Spec.StartingLoyalty, for cards that never went through deck
//     import (tokens, fixtures, the demo seed).
//
// The already-has-loyalty guard is what keeps the two from adding
// up: a deck-imported catalog planeswalker would otherwise enter
// with double its printed loyalty. It also makes the call idempotent
// for the entry paths that fire the hook more than once.
//
// Counters go through AddCounterForEffect rather than being written
// directly so the CR 614 counter-replacement pipeline still sees
// them — a planeswalker entering under Doubling Season gets its
// loyalty doubled (CR 121.3), which a direct map write would skip.
//
// Timing matters: this runs as part of the battlefield-entry path,
// which is strictly before the next priority-grant boundary, so the
// 0-loyalty SBA at mutations.go:1836 never observes the walker in
// its unstamped state.
func (g *Game) stampStartingLoyaltyLocked(cardID uuid.UUID, oracleID string) {
	var card *Card
	for i := range g.Battlefield.Cards {
		if g.Battlefield.Cards[i].InstanceID == cardID {
			card = &g.Battlefield.Cards[i]
			break
		}
	}
	if card == nil || !card.IsPlaneswalker() {
		return
	}
	if card.Counters[CounterLoyalty] > 0 {
		return
	}
	loyalty := card.StartingLoyalty
	if loyalty <= 0 && CatalogStartingLoyalty != nil && oracleID != "" {
		loyalty = CatalogStartingLoyalty(oracleID)
	}
	if loyalty <= 0 {
		// Nothing printed and nothing in the catalog. Leave it at
		// zero and let CR 704.5i do its job — inventing a loyalty
		// value here would make planeswalkers unkillable.
		return
	}
	if err := g.AddCounterForEffect(cardID, CounterLoyalty, loyalty); err != nil {
		g.EmitEvent(Event{
			Kind:     EventEffectError,
			Source:   cardID,
			ErrorMsg: err.Error(),
		})
	}
}

// IsAutoCard is the exported wrapper for the view layer. Returns
// true when the card's oracle ID is in the catalog. Called from
// protocol.viewOfCard when stamping CardView.Auto. Nil hook returns
// false — no catalog means no auto.
func IsAutoCard(oracleID string) bool {
	if IsCatalogCard == nil || oracleID == "" {
		return false
	}
	return IsCatalogCard(oracleID)
}

// TargetModeFor returns the catalog's declared target prompt mode
// for the given oracle ID, or empty string if the card isn't in
// the catalog / has no target prompt. Called from protocol.viewOfCard
// when stamping CardView.TargetMode.
func TargetModeFor(oracleID string) string {
	if CatalogTargetMode == nil || oracleID == "" {
		return ""
	}
	return CatalogTargetMode(oracleID)
}
